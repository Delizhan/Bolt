﻿namespace Bolt
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox_Bolt = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_orenda = new System.Windows.Forms.Button();
            this.pictureBox_info = new System.Windows.Forms.PictureBox();
            this.button_lesson1 = new System.Windows.Forms.Button();
            this.button_lesson2 = new System.Windows.Forms.Button();
            this.button_lesson3 = new System.Windows.Forms.Button();
            this.button_lesson4 = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Bolt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_info)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_Bolt
            // 
            this.pictureBox_Bolt.Image = global::Bolt.Properties.Resources.image_1;
            this.pictureBox_Bolt.Location = new System.Drawing.Point(12, 12);
            this.pictureBox_Bolt.Name = "pictureBox_Bolt";
            this.pictureBox_Bolt.Size = new System.Drawing.Size(150, 87);
            this.pictureBox_Bolt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Bolt.TabIndex = 1;
            this.pictureBox_Bolt.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(168, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(349, 54);
            this.label1.TabIndex = 3;
            this.label1.Text = "Електросамокати";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Bolt.Properties.Resources.Group_2;
            this.pictureBox2.Location = new System.Drawing.Point(-8, 105);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1920, 278);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // button_orenda
            // 
            this.button_orenda.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button_orenda.Font = new System.Drawing.Font("Segoe UI Semibold", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_orenda.ForeColor = System.Drawing.SystemColors.Control;
            this.button_orenda.Location = new System.Drawing.Point(727, 163);
            this.button_orenda.Name = "button_orenda";
            this.button_orenda.Size = new System.Drawing.Size(452, 71);
            this.button_orenda.TabIndex = 7;
            this.button_orenda.Text = "Орендувати самокат";
            this.button_orenda.UseVisualStyleBackColor = false;
            this.button_orenda.Click += new System.EventHandler(this.button_orenda_Click);
            // 
            // pictureBox_info
            // 
            this.pictureBox_info.Image = global::Bolt.Properties.Resources.Group_7__1_;
            this.pictureBox_info.Location = new System.Drawing.Point(38, 400);
            this.pictureBox_info.Name = "pictureBox_info";
            this.pictureBox_info.Size = new System.Drawing.Size(1790, 586);
            this.pictureBox_info.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_info.TabIndex = 8;
            this.pictureBox_info.TabStop = false;
            // 
            // button_lesson1
            // 
            this.button_lesson1.Image = global::Bolt.Properties.Resources.Group_5;
            this.button_lesson1.Location = new System.Drawing.Point(1294, 554);
            this.button_lesson1.Name = "button_lesson1";
            this.button_lesson1.Size = new System.Drawing.Size(518, 88);
            this.button_lesson1.TabIndex = 9;
            this.button_lesson1.UseVisualStyleBackColor = true;
            this.button_lesson1.Click += new System.EventHandler(this.button_lesson1_Click);
            // 
            // button_lesson2
            // 
            this.button_lesson2.Image = global::Bolt.Properties.Resources.Group_8;
            this.button_lesson2.Location = new System.Drawing.Point(1294, 658);
            this.button_lesson2.Name = "button_lesson2";
            this.button_lesson2.Size = new System.Drawing.Size(518, 88);
            this.button_lesson2.TabIndex = 10;
            this.button_lesson2.UseVisualStyleBackColor = true;
            this.button_lesson2.Click += new System.EventHandler(this.button_lesson2_Click);
            // 
            // button_lesson3
            // 
            this.button_lesson3.Image = global::Bolt.Properties.Resources.Group_9;
            this.button_lesson3.Location = new System.Drawing.Point(1294, 762);
            this.button_lesson3.Name = "button_lesson3";
            this.button_lesson3.Size = new System.Drawing.Size(518, 88);
            this.button_lesson3.TabIndex = 11;
            this.button_lesson3.UseVisualStyleBackColor = true;
            this.button_lesson3.Click += new System.EventHandler(this.button_lesson3_Click);
            // 
            // button_lesson4
            // 
            this.button_lesson4.Image = global::Bolt.Properties.Resources.Group_5__1_;
            this.button_lesson4.Location = new System.Drawing.Point(1294, 866);
            this.button_lesson4.Name = "button_lesson4";
            this.button_lesson4.Size = new System.Drawing.Size(518, 88);
            this.button_lesson4.TabIndex = 12;
            this.button_lesson4.UseVisualStyleBackColor = true;
            this.button_lesson4.Click += new System.EventHandler(this.button_lesson4_Click);
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.Color.Brown;
            this.button_exit.Font = new System.Drawing.Font("Segoe UI Semibold", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_exit.ForeColor = System.Drawing.SystemColors.Control;
            this.button_exit.Location = new System.Drawing.Point(1701, 26);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(179, 54);
            this.button_exit.TabIndex = 14;
            this.button_exit.Text = "Вийти";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1902, 993);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_lesson4);
            this.Controls.Add(this.button_lesson3);
            this.Controls.Add(this.button_lesson2);
            this.Controls.Add(this.button_lesson1);
            this.Controls.Add(this.pictureBox_info);
            this.Controls.Add(this.button_orenda);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox_Bolt);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bolt | Електросамокати";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Bolt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_info)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox_Bolt;
        private Label label1;
        private PictureBox pictureBox2;
        private Button button_orenda;
        private PictureBox pictureBox_info;
        private Button button_lesson1;
        private Button button_lesson2;
        private Button button_lesson3;
        private Button button_lesson4;
        private Button button_exit;
    }
}