﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bolt.ClassesAndInterfaces
{
    public class Gift
    {
        private byte discount = 30;
        public byte Discount { get => discount; }
    }
}
